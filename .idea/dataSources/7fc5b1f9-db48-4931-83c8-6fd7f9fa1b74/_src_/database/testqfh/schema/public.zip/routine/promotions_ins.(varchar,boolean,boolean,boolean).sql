CREATE FUNCTION promotions_ins (usernamei character varying, promotions boolean, out_of_queue boolean, first_of_queue boolean) RETURNS void
	LANGUAGE plpgsql
AS $$
DECLARE 
	userid promotions.user_id%TYPE;
BEGIN
	SELECT user_id INTO userid FROM users WHERE users.user_name = usernameI;
    INSERT INTO promotions VALUES (DEFAULT, promotions, out_of_queue, first_of_queue, userid);
END;
$$
