CREATE VIEW deleted_queue AS
SELECT unsorted_queue.user_id,
    unsorted_queue.user_name,
    unsorted_queue.password,
    unsorted_queue.date_registration,
    unsorted_queue.deleted,
    unsorted_queue.wish_id,
    unsorted_queue.rooms_count,
    unsorted_queue.kindergarden,
    unsorted_queue.school,
    unsorted_queue.district,
    unsorted_queue.housing_id,
    unsorted_queue.date_application,
    unsorted_queue.condition,
    unsorted_queue.promotions_id,
    unsorted_queue.promotions,
    unsorted_queue.out_of_queue,
    unsorted_queue.first_of_queue
   FROM unsorted_queue
  WHERE (unsorted_queue.deleted = true)