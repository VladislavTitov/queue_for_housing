CREATE FUNCTION housing_ins (usernamei character varying, date_application date, conditioni integer) RETURNS void
	LANGUAGE plpgsql
AS $$
DECLARE 
	userid housing.user_id%TYPE;
BEGIN
	SELECT user_id INTO userid FROM users WHERE users.user_name = usernameI;
    INSERT INTO housing VALUES (DEFAULT, date_application, conditionI, userid);
END;
$$
