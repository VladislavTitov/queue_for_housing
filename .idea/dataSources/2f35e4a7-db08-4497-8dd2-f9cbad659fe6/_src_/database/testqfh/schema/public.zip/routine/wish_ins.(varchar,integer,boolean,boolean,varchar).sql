CREATE FUNCTION wish_ins (usernamei character varying, rooms_count integer, kindergarden boolean, school boolean, district character varying) RETURNS void
	LANGUAGE plpgsql
AS $$
DECLARE 
	userid wishes.user_id%TYPE;
BEGIN
	SELECT user_id INTO userid FROM users WHERE users.user_name = usernameI;
    INSERT INTO wishes VALUES (DEFAULT, rooms_count, kindergarden, school, district, userid);
END;
$$
