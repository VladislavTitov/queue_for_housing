CREATE FUNCTION mother_ins (usernamei character varying, mother_surname character varying, mother_name character varying, mother_patronymic character varying) RETURNS void
	LANGUAGE plpgsql
AS $$
DECLARE 
	userid mothers.user_id%TYPE;
BEGIN
	SELECT user_id INTO userid FROM users WHERE users.user_name = usernameI;
    INSERT INTO mothers VALUES (DEFAULT, mother_surname, mother_name, mother_patronymic, userid);
END;
$$
