CREATE VIEW sorted_out_of_queue AS
SELECT unsorted_normal_queue.user_id,
    unsorted_normal_queue.user_name,
    unsorted_normal_queue.password,
    unsorted_normal_queue.date_registration,
    unsorted_normal_queue.deleted,
    unsorted_normal_queue.wish_id,
    unsorted_normal_queue.rooms_count,
    unsorted_normal_queue.kindergarden,
    unsorted_normal_queue.school,
    unsorted_normal_queue.district,
    unsorted_normal_queue.housing_id,
    unsorted_normal_queue.date_application,
    unsorted_normal_queue.condition,
    unsorted_normal_queue.promotions_id,
    unsorted_normal_queue.promotions,
    unsorted_normal_queue.out_of_queue,
    unsorted_normal_queue.first_of_queue
   FROM unsorted_normal_queue
  WHERE (unsorted_normal_queue.out_of_queue = true)
  ORDER BY unsorted_normal_queue.date_application