CREATE FUNCTION child_ins (usernamei character varying, child_surname character varying, child_name character varying, child_patronymic character varying) RETURNS void
	LANGUAGE plpgsql
AS $$
DECLARE 
	userid children.user_id%TYPE;
BEGIN
	SELECT user_id INTO userid FROM users WHERE users.user_name = usernameI;
    INSERT INTO children VALUES (DEFAULT, child_surname, child_name, child_patronymic, userid);
END;
$$
