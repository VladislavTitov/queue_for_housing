CREATE FUNCTION father_ins (usernamei character varying, father_surname character varying, father_name character varying, father_patronymic character varying) RETURNS void
	LANGUAGE plpgsql
AS $$
DECLARE 
	userid fathers.user_id%TYPE;
BEGIN
	SELECT user_id INTO userid FROM users WHERE users.user_name = usernameI;
    INSERT INTO fathers VALUES (DEFAULT, father_surname, father_name, father_patronymic, userid);
END;
$$
